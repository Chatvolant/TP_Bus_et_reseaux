#include <stdio.h>

void configuration_BMP (void);
void calibration (void);
void gettemp (void);

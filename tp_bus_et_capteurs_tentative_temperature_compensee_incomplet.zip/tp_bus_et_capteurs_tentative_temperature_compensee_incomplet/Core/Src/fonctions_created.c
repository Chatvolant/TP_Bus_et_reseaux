/*
 * fonctions_created.c
 *
 *  Created on: Oct 19, 2023
 *      Author: chizu
 */

#include "main.h"
#include "i2c.h"
#include "usart.h"
#include "gpio.h"
#include <stdio.h>
#include "fonctions_created.h"
#include "bmp280.h"

uint16_t slave_address=0x77;
uint8_t address_register=0xD0;

uint8_t address_calib_reg=0x88;

uint8_t temperature_reg=0xFA;
uint8_t temperature[3];
uint8_t press[3];

//extern struct bme280_calib_data calibData;
extern s_calib struct_calib;


//void configuration_BMP (I2C_HandleTypeDef *hi2c)

void configuration_BMP (void)
{
	uint8_t data;
	uint8_t data2;
	uint8_t transmission_data[]={0xF4,0x57};


	HAL_I2C_Master_Transmit(&hi2c1, (slave_address << 1), &address_register, 1, HAL_MAX_DELAY);
	HAL_I2C_Master_Receive(&hi2c1, (slave_address << 1), &data, 1, HAL_MAX_DELAY);
	printf("id :0x%02X\n\r",data);
	HAL_Delay(1000);

	//envoi de l'adresse du registre à écrire, suivi de la valeur du registre
	// écriture, configuration : mode normal, Pressure oversampling x16, Temperature oversampling x2
	HAL_I2C_Master_Transmit(&hi2c1, (slave_address << 1), transmission_data, 2, HAL_MAX_DELAY);

	//Lecture du registre ctrl_meas mode pour voir si on a bien configuré comme on voulait
	//HAL_I2C_Master_Transmit(&hi2c1, (slave_address << 1), &address_register2, 1, HAL_MAX_DELAY);
	HAL_I2C_Master_Receive(&hi2c1, (slave_address << 1), &data2, 1, HAL_MAX_DELAY);
	printf("config :0x%02X\n\r",data2);
}

void calibration (void) { //pour l'instant je fais que la température
	struct bme280_calib_data calibData;
	struct bme280_calib_data *pcalibData = &calibData;

	uint16_t calibContenu[11];

	//Récupération en une fois du contenu des registres qui contiennent l'étalonnage du BMP280.
	HAL_I2C_Master_Transmit(&hi2c1, (slave_address << 1), &address_calib_reg, 1, HAL_MAX_DELAY);
	HAL_I2C_Master_Receive(&hi2c1, (slave_address << 1), &calibContenu, 11, HAL_MAX_DELAY);
	//HAL_I2C_Master_Receive(&hi2c1, (slave_address << 1), &calibData.dig_t1, 2, HAL_MAX_DELAY);
	for (int i = 0; i<26;i++)
	{
		printf("calibration :0x%02X\n\r",calibContenu[i]);
	}
}

void gettemp (void){
	uint8_t temp_msb,temp_lsb,temp_xlsb,ut;

	//Lecture de la température
	HAL_I2C_Master_Transmit(&hi2c1, (slave_address << 1), &temperature_reg, 1, HAL_MAX_DELAY);
	HAL_I2C_Master_Receive(&hi2c1, (slave_address << 1), &temperature, 3, HAL_MAX_DELAY);

	temp_msb=temperature[0];
	temp_lsb=temperature[1];
	temp_xlsb=temperature[2];

	ut = (temp_msb << 12) | (temp_lsb << 4) | (temp_xlsb >> 4); //masque OU + décalage pour récupérer bonnes valeurs. Dans la doc, il est dit que la temperature est codée sur 20 bits.

	printf("temperature : 0X%05lX\n\r",ut);

}

void getpressure (void){
	uint8_t press_msb,press_lsb,press_xlsb,up;
	static uint8_t press_reg = 0xF7;

	//Lecture de la température
	HAL_I2C_Master_Transmit(&hi2c1, (slave_address << 1), &press_reg, 1, HAL_MAX_DELAY);
	HAL_I2C_Master_Receive(&hi2c1, (slave_address << 1), &press, 3, HAL_MAX_DELAY);

	press_msb=press[0];
	press_lsb=press[1];
	press_xlsb=press[2];

	up = (press_msb << 12) | (press_lsb << 4) | (press_xlsb >> 4); //masque OU + décalage pour récupérer bonnes valeurs. Dans la doc, il est dit que la temperature est codée sur 20 bits.

	printf("pression : 0X%05lX\n\r",up);

}


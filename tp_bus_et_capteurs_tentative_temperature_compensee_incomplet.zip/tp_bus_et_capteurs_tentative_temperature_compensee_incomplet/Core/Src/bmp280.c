/*
 * bmp280.c
 *
 *  Created on: Nov 23, 2023
 *      Author: chizu
 */

// Returns temperature in DegC, double precision. Output value of “51.23” equals 51.23 DegC.
// t_fine carries fine temperature as global value

#include "bmp280.h"

typedef int32_t BMP280_S32_t;
s_calib struct_calib;

//problem avec dig_T1 car on la pas initialisé, donc faut lire ce qu'on
//a dans le registre de calibration avant d'utiliser cette fonction

double bmp280_compensate_T_double(BMP280_S32_t adc_T)
{
	double var1, var2, T;
	//mettre ici fonction pour récupérer contenu calibration

	var1 = (((double)adc_T)/16384.0 - ((double)struct_calib.dig_t1)/1024.0) * ((double)struct_calib.dig_t2);
	var2 = ((((double)adc_T)/131072.0 - ((double)struct_calib.dig_t1)/8192.0) *
			(((double)adc_T)/131072.0 - ((double)struct_calib.dig_t1)/8192.0)) * ((double)struct_calib.dig_t3);
	struct_calib.t_fine = (BMP280_S32_t)(var1 + var2);
	T = (var1 + var2) / 5120.0;
	return T;
}
// Returns pressure in Pa as double. Output value of “96386.2” equals 96386.2 Pa = 963.862 hPa
double bmp280_compensate_P_double(BMP280_S32_t adc_P)
{
	double var1, var2, p;
	var1 = ((double)struct_calib.t_fine/2.0) - 64000.0;
	var2 = var1 * var1 * ((double)struct_calib.dig_p6) / 32768.0;
	var2 = var2 + var1 * ((double)struct_calib.dig_p5) * 2.0;
	var2 = (var2/4.0)+(((double)struct_calib.dig_p4) * 65536.0);
	var1 = (((double)struct_calib.dig_p3) * var1 * var1 / 524288.0 + ((double)struct_calib.dig_p2) * var1) / 524288.0;
	var1 = (1.0 + var1 / 32768.0)*((double)struct_calib.dig_p1);
	if (var1 == 0.0)
	{
		return 0; // avoid exception caused by division by zero
	}
	p = 1048576.0 - (double)adc_P;
	p = (p - (var2 / 4096.0)) * 6250.0 / var1;
	var1 = ((double)struct_calib.dig_p9) * p * p / 2147483648.0;
	var2 = p * ((double)struct_calib.dig_p8) / 32768.0;
	p = p + (var1 + var2 + ((double)struct_calib.dig_p7)) / 16.0;
	return p;
}
